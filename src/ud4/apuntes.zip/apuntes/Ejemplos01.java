package ud4.apuntes;

public class Ejemplos01 {
    public static void main(String[] args) {
        int[] edad; // Declaración Variable

        edad = new int[5]; // Crea/instancia el array

        edad[0] = 28; // Asignar valores a elementos
        edad[1] = 35;
        edad[2] = 18;
        
        
        System.out.println("La edad de la persona 2 es " + edad[2] +  " años.");
        //edad[5] = 12;

        System.out.println("Fin de Programa");
    }
}
