package ud4.apuntes;

public class TresTablas {
    public static void main(String[] args) {
        long[] enteros = {1, 2, 3, 4, 5};
        double[] reales = new double[5];
        boolean[] logicos = new boolean[5];
        Boolean[] logicosEnvolvente = new Boolean[5];

        System.out.println(enteros);
        System.out.println(reales);
        System.out.println(logicos);
        System.out.println(logicosEnvolvente);

        System.out.println("Fin Programa");
    }
}
