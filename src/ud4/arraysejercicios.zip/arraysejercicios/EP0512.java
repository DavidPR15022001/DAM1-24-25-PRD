package ud4.arraysejercicios;

import java.util.Arrays;

public class EP0512 {
    public static void desordenar(int t[]) {
        int[] t1 = {5, 6, 4, 7, 8, 9};
        Arrays.sort(t1);
        
    }

}
