package ud5.mulleres;

public interface IActivista {
   public abstract String getCausaDefendida(); 
}
