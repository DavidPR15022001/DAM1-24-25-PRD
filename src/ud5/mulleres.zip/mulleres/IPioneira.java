package ud5.mulleres;

public interface IPioneira {
    public abstract String getDescubrimentoOuAporte();
}
