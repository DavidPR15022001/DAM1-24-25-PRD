package ud5.praiasdegalicia;

public class AppBanderaAzul {
    public static void main(String[] args) {
        // Carga las playas desde el fichero JSON en un array de Praias
        Praia[] praias = Util.importarPraias("praias.json");

        // TODO Resuelve el problema propuesto
        // ...
    }
}
