// David Padín Ruibal //
package ud2.prdexamenrec;

import java.util.Scanner;

public class EstadisticaEstaturas {
    public static void main(String[] args) {
        // Declaración de variables y constantes
        double estatura, sumaEstaturas = 0, mediaEstaturas = 0, estaturaMasAlta = 0, estaturaMasBaja = 0;
        int numeroAlumnos = 0;

        // Entrada de datos
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduce las estaturas en cm de los alumnos (número negativo para terminar)");

        // Lectura adelantada
        estatura = sc.nextDouble();
        while (estatura >= 0) {
            numeroAlumnos++; // Contador de alumnos
            sumaEstaturas += estatura; // Acumulador de estaturas
            if (estatura < 0) {
            System.out.println("Numero de alumnos" + numeroAlumnos);
            System.out.printf("Media de estaturas %.2f", mediaEstaturas);
            System.out.println("Estatura más alta" + estaturaMasAlta);
            System.out.println("Estatura más baja" + estaturaMasBaja);
            }
            if (estatura > 0) {
            mediaEstaturas = sumaEstaturas / numeroAlumnos;
            }
            if (estatura > estatura) {
                estaturaMasAlta = estatura;
            }
            if (estatura == 0.1) {
                estaturaMasBaja = estatura;
            } else {
                System.out.println("No has introducido ninguna edad válida.");
            }
            estatura = sc.nextDouble();
            sc.close();
        }  
    }
}


